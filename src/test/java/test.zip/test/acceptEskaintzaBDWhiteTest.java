package test;

public class acceptEskaintzaBDWhiteTest {

}
