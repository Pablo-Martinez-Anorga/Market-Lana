package test;

public class acceptEskaintzaMockBlackTtest {

}
