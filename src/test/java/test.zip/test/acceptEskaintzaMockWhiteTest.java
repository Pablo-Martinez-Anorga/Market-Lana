package test;

public class acceptEskaintzaMockWhiteTest {

}
